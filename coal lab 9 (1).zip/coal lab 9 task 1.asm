MOV CX, 5      

START:
MOV AH, 02H      
MOV DL, 'A'     
INT 21H         

DEC CX           
JNZ START       




