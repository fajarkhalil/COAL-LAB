.DATA
msg1 db 'Positive$'
msg2 db 'Negative$'

.CODE
MOV AH, 01H      
INT 21H          

SUB AL, 30H      

CMP AL, 0        
JGE POSITIVE    

MOV AH, 09H
LEA DX, msg2
INT 21H
JMP END

POSITIVE:
MOV AH, 09H
LEA DX, msg1
INT 21H

END:




