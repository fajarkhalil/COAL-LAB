.DATA
msgG db 'Greater$'
msgS db 'Smaller$'
msgE db 'Equal$'

.CODE

MOV AH, 01H
INT 21H
SUB AL, 30H
MOV BL, AL        


MOV AH, 01H
INT 21H
SUB AL, 30H
MOV BH, AL        


CMP BL, BH
JG GREATER
JL SMALLER
JE EQUAL

GREATER:
MOV AH, 09H
LEA DX, msgG
INT 21H
JMP END

SMALLER:
MOV AH, 09H
LEA DX, msgS
INT 21H
JMP END

EQUAL:
MOV AH, 09H
LEA DX, msgE
INT 21H

END:




