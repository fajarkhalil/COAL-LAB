 MOV CX, 5       

PRINT:
MOV AH, 02H     
MOV DL, '*'     
INT 21H         

LOOP PRINT




