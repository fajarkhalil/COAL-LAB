MOV CX, 10      
MOV DL, 9       

START:
MOV AH, 02H     
ADD DL, 30H    
INT 21H        

SUB DL, 30H     
DEC DL         

LOOP START




