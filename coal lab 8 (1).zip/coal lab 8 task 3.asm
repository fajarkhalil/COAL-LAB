.DATA
newline db 0dh,0ah,'$'  

.CODE
MOV CX, 26        
MOV DL, 'A'       

START:

MOV AH, 02H
INT 21H


MOV AH, 09H
LEA DX, newline
INT 21H

INC DL           
LOOP START




