MOV CX, 5        
MOV DL, 0        

START:
MOV AH, 02H     
ADD DL, 30H     
INT 21H          

SUB DL, 30H     
ADD DL, 2       

MOV AH, 02H
MOV DL, ' '      
INT 21H

LOOP START




